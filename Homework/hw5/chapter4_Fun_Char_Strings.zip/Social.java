/**
 *Author:
 *Intro to Java Programming CIT 130
 * Assignment
 * Due Date:
 * Time to complete: zz hours
 */

/**
 A program to process social security number
*/

import java.util.Scanner;

public class Social {
    public static void main(String [] args) {
         Scanner input = new Scanner(System.in);

		//Get the INPUT
		System.out.print("Enter a SSN - please use the format of: DDD-DD-DDDD - D stands for a digit: ");
		String ssn = input.nextLine();

		//the following shows how to use a simple set of conditions and assign to a boolean variable
		//you can also break the conditions into smaller segments
		//Note the use of the isDigit method to identify if a given character is a digit
		//Note the use of charAt to get a character at a given position

		boolean isValid = ssn.length() == 11 && Character.isDigit(ssn.charAt(0)) &&
		Character.isDigit(ssn.charAt(1)) && Character.isDigit(ssn.charAt(2)) &&
		ssn.charAt(3) == '-' && Character.isDigit(ssn.charAt(4)) &&
		Character.isDigit(ssn.charAt(5)) && ssn.charAt(6) == '-' &&
		Character.isDigit(ssn.charAt(7)) && Character.isDigit(ssn.charAt(8)) &&
		Character.isDigit(ssn.charAt(9)) && Character.isDigit(ssn.charAt(10));

		if (isValid)
		  System.out.println(ssn + " is a valid social security number");
		else
		  System.out.println(ssn + " is an invalid social security number");

		//get the last 4 digits
		//here is an example: 123-45-6789
		//                    01234567890     makes it easier to process the data on paper!
		if (ssn.length() == 11){
			String lastFour = ssn.substring(ssn.length() - 4);  //11-4 = 7 - start at location 7 and go to the end
			System.out.println("the lats 4 digits are: " + lastFour);
		}
		else
			System.out.println("The input value does not have the correct length");
	}//main
}//Social