/**
 *Author:
 *Intro to Java Programming CIT 130
 * Assignment
 * Due Date:
 * Time to complete: zz hours
 */

/**
 A program to compute the area of a polygon.
*/

import java.util.Scanner;

public class Polygon {
    public static void main(String [] args) {
         Scanner input = new Scanner(System.in);

		//Get the INPUT
		 System.out.println("How many sides does your polygon have and "
				 + "what is the legth of one side? Enter a space between your answers.\n");
		 int sides = input.nextInt();
		 double side = input.nextDouble();

		 //process the data
		 double area = ((sides*Math.pow(side, 2))/ (4*Math.tan(Math.PI/sides)));

		 //OUTPUT the desired result
		 System.out.printf("The area of your Polygon is %4.2f\n",area);
	}//main
}//Polygon